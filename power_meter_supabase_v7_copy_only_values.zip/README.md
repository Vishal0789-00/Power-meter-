
# Power Meter Reader v5 — Day-wise readings only

## Exact workflow

- Upload up to **6 floor images at once**.
- One image = one floor.
- Each image contains 8 opened meter panels.
- Positions 1–4 = West: Main, Raw, Lighting, HVAC.
- Positions 5–8 = East: Main, Raw, Lighting, HVAC.
- Extract only:
  - `Total Energy` -> kWh
  - `Apparent Power per Hour` -> kVAh
- **Uploaded images are NOT saved in Supabase.**
- Only the extracted readings are saved.
- Readings are stored **day-wise** using `reading_date`.
- Reprocessing a floor on the same date replaces that floor's previous readings for that user/date.

## What is stored

Each row stores:

```text
Reading Date
Floor
Side
Meter
Position
kWh
kVAh
Status
Created At
```

No image path and no image file are stored.

## Excel

For each floor:

**Copy kWh only**

```text
1st Floor - kWh
        West        East
Main    ...
Raw     ...
Lighting ...
HVAC    ...
```

**Copy kVAh only**

```text
1st Floor - kVAh
        West        East
Main    ...
Raw     ...
Lighting ...
HVAC    ...
```

## Supabase setup

1. Create a Supabase project.
2. Run `supabase/migrations/001_meter_reader.sql` in SQL Editor.
3. Enable Email Auth.
4. Set the OpenAI API key as an Edge Function secret:

```bash
supabase secrets set OPENAI_API_KEY=your_openai_api_key
```

5. Deploy:

```bash
supabase functions deploy process-floor-images
```

6. Copy `.env.example` to `.env.local` and set:

```text
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

7. Install and run:

```bash
npm install
npm run dev
```

## Privacy behavior

The browser sends each selected image to the Edge Function for extraction. The Edge Function sends it to the vision model and writes only the structured readings to Postgres. There is no Supabase Storage bucket or image path in this version.

For strict retention/privacy requirements, review your AI provider's current data-use policy and your organization's requirements before production use.

## Important

Do not put the OpenAI API key or Supabase secret key in GitHub or frontend `.env` files.


## v6 output layout

The PC results page now displays the saved readings in this order:

```text
Reading Date: 16-08-2026

1st Floor

kWh Readings
Meter       West        East
Main        ...
Raw         ...
Lighting    ...
HVAC        ...

kVAh Readings
Meter       West        East
Main        ...
Raw         ...
Lighting    ...
HVAC        ...

2nd Floor

kWh Readings
...
```

The copy buttons also put the date and floor at the top of the copied Excel block:

```text
Date    16-08-2026
Floor   1st Floor

kWh
Meter   West    East
Main    ...
Raw     ...
Lighting ...
HVAC    ...
```

and similarly for kVAh.


## Copy behavior

The screen may show the date and floor name for organization, but the Copy buttons do NOT copy them.

**Copy kWh only** copies:

```text
Meter   West    East
Main    ...
Raw     ...
Lighting ...
HVAC    ...
```

**Copy kVAh only** copies:

```text
Meter   West    East
Main    ...
Raw     ...
Lighting ...
HVAC    ...
```

No date, floor name, or extra information is included in the copied block.
